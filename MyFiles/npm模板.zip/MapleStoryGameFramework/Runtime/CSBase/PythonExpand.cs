using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  static class PythonExpand 
{
    /*
    //泛型包括了obj
    public static void append<T>(this List<T> list,T item)
    {
        list.Add(item);
    }
    
    public static T pop<T>(this List<T> list)
    {
        T res = default;
        int idx = list.Count - 1;
        res = list[idx];
        list.RemoveAt(idx);
        return res;
    }
    */
}
