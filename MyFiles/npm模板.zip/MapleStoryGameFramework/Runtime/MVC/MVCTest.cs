using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UniRx;
public class MVCTest : MonoBehaviour
{
/*    public IntReactiveProperty age = new IntReactiveProperty(3);

    public HpClickUI ui;


    public string ageStr=> "age is "+age.Value;

    private void Start()
    {

        age.Subscribe((age) =>
        {
            print("age is "+age);
            if (age >= 10)
            {
                ui.btn.interactable = false;
            }
            //print("hh");
            ui.textUpdate(ageStr);
            ui.textUpdate2(ageStr);
        });
        
        ui.btnClick(() =>
        {
            age.Value += 1;
        });

        //age.SetValueAndForceNotify(0);
        //age.ToReactiveProperty(xx);
        
        //var clickStream = Observable.EveryUpdate().Where(_ => Input.GetMouseButtonDown(0));
        //clickStream.Subscribe(_=>{});

    }*/
}
